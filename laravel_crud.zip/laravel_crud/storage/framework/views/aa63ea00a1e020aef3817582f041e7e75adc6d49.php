<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
</head>
<body>
    <h1>This is home PAge </h1>

    <nav>
        <ul>
            <li><a href="<?php echo e(Route('addproduct')); ?>">Add product</a></li>
            <li><a href="<?php echo e(Route('productshows')); ?>">Manage product</a></li>
        </ul>
    </nav>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravelProject\laravel_crud\resources\views/frontend/home.blade.php ENDPATH**/ ?>
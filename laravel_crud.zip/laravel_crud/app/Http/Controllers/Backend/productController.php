<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Backend\product;

class productController extends Controller
{
    function home(){
        return view('frontend.home');
    }
    public function addproduct(){
        return view('frontend.addproduct');
    }
    public function showproduct(Request $rqst){
        
        $product = new product();

        $product->pname = $rqst->pname;
        $product->pdes = $rqst->pdes;
        $product->cat = $rqst->cat;
        $product->scat = $rqst->scat;
        $product->price = $rqst->price;
        $product->status = $rqst->status;

        $product->save();
        return redirect()->route("productshows");
    }
    public function productshows(){
        $products = product::all();
        return view('frontend.showproduct',compact('products'));
    }
    public function editproduct($id){
        $product = product::find($id);
        return view('frontend.editproduct',compact('product'));
    }
    public function updateproduct(Request $rqst, $id){
        $product = product::find($id);

        $product->pname = $rqst->pname;
        $product->pdes = $rqst->pdes;
        $product->cat = $rqst->cat;
        $product->scat = $rqst->scat;
        $product->price = $rqst->price;
        $product->status = $rqst->status;

        $product->update();
        return redirect()->route("productshows");
    }
    public function deleteproduct($id){
        $product = product::find($id);
        $product->delete();
        return redirect()->route("productshows");
    }
    public function statusupdate($id){
        $product = product::find($id);

        if ($product->status==1) {
            $product->status=2;
        }
        else{
            $product->status=1;
        }

        $product->update();
        return redirect()->route("productshows");
    }
}

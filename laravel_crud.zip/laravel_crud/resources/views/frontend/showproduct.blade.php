<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    
    <div class="container">
        <div class="row mt-5">
            
            <div class="col-md-12">
                <table class="table">
                    <tr>
                        <th>Sl No</th>
                        <th>Product Name</th>
                        <th>Product Description</th>
                        <th>Product Category</th>
                        <th>Product sub-Category</th>
                        <th>price</th>
                        <th>status</th>
                        <th>Action</th>
                    </tr>
                    <?php $sl=1; ?>
                    @foreach($products as $data) 
                        <tr>
                            <td>{{$sl}}</td>
                            <td>{{$data->pname}}</td>
                            <td>{{$data->pdes}}</td>
                            <td>{{$data->cat}}</td>
                            <td>{{$data->scat}}</td>
                            <td>{{$data->price}}</td>

                            <td>
                                @if ($data->status==1)
                                    <button data-toggle="modal" data-target="#status{{ $data->id }}" class="btn btn-primary btn-sm"><i class="fa-solid fa-check"></i></button>

                                    {{-- <a href="{{route('statusupdate',$data->id)}}" class="btn btn-primary btn-sm"><i class="fa-solid fa-check"></i></a> --}}

                                    @else
                                <button data-toggle="modal" data-target="#status{{ $data->id }}" class="btn btn-danger btn-sm"><i class="fa-solid fa-xmark"></i></button>

                                    {{-- <a href="{{route('statusupdate',$data->id)}}" class="btn btn-danger btn-sm"><i class="fa-solid fa-xmark"></i></i></a> --}}
                                @endif
                            </td>
                            
                            
                            <td>
                                <button data-toggle="modal" data-target="#update{{ $data->id }}" class="btn btn-primary btn-sm">Edit</button>

                                {{-- <a href="{{ route('editproduct',$data->id)}}" class="btn btn-primary btn-sm">Edit</a> --}}

                                <button data-toggle="modal" data-target="#delete{{ $data->id }}" class="btn btn-danger btn-sm">Delete</button>

                                {{-- <a href="{{ route('deleteproduct',$data->id)}}" class="btn btn-danger btn-sm">Delete</a> --}}
                            </td>
                        </tr>
                        <?php $sl++; ?>



<!-- Modal for status-->
<div class="modal fade" id="status{{ $data->id }}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Confirmation Message</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          Are you sure you want change this status
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">No</button>
            <a href="{{route('statusupdate',$data->id)}}" class="btn btn-danger btn-sm">Yes</a>
          {{-- <button type="button" class="btn btn-primary">Yes</button> --}}
        </div>
      </div>
    </div>
  </div>


  
  <!-- Modal For Delete -->
  <div class="modal fade" id="delete{{ $data->id }}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Confirmation message</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          Are you sure you want this user?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <a href="{{ route('deleteproduct',$data->id)}}" class="btn btn-danger btn-sm">Delete</a> 
        </div>
      </div>
    </div>
  </div>

  
  <!-- Modal for update -->
  <div class="modal fade" id="update{{ $data->id }}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Update Confirmation</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <form action="{{ route('updateproduct',$data->id)}}" method="POST">
                @csrf
                <div class="form-group">
                    <label for="pname">Product Name </label>
                    <input type="text" value="{{$data->pname}}" id="pname" name="pname" class="form-control" placeholder="product Name">
                </div>
                <div class="form-group">
                    <label for="pdes">Product Description </label>
                    <input type="text" id="pdes" value="{{$data->pdes}}" name="pdes" class="form-control" placeholder="product Description">
                </div>
                <div class="form-group">
                    <label for="cat">Product Category </label>
                    <input type="text" id="cat" value="{{$data->cat}}" name="cat" class="form-control" placeholder="product Category">
                </div>
                <div class="form-group">
                    <label for="scat">Product sub Category </label>
                    <input type="text" id="scat" value="{{$data->scat}}" name="scat" class="form-control" placeholder="product sub Category">
                </div>
                <div class="form-group">
                    <label for="price">Price </label>
                    <input type="text" id="price" value="{{$data->price}}" name="price" class="form-control" placeholder="price">
                </div>
                <div class="form-group">
                    <label for="status">Select </label>
                    <select name="status" value="{{$data->status}}" id="status" class="form-control">
                        <option value="0">--Select Here--</option>
                        <option value="1" @if($data->status==1)selected @endif>Active</option>
                        <option value="2" @if($data->status==2)selected @endif>Inactive</option>
                    </select>
                </div>
                
            
        </div>
        <div class="modal-footer">
         
          {{-- <button type="button" class="btn btn-primary">Save changes</button> --}}
          <button class="form-control btn btn-primary">Update</button>
        </div>
    </form>
      </div>
    </div>
  </div> 
  {{-- Ending update Model  --}}

                    @endforeach
                </table>
            </div>
        </div>
        <a href="{{route('addproduct')}}" class="btn btn-primary">Add Products</a>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<!-- Needed Script -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
crossorigin="anonymous"></script>


</body>
</html>
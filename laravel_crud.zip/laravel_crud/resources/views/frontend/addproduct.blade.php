<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    
    <div class="container">
        <div class="row mt-5">
            <div class="col-md-6 offset-md-3">
                <form action="{{ route('showproduct') }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label for="pname">Product Name </label>
                        <input type="text" id="pname" name="pname" class="form-control" placeholder="product Name">
                    </div>
                    <div class="form-group">
                        <label for="pdes">Product Description </label>
                        <input type="text" id="pdes" name="pdes" class="form-control" placeholder="product Description">
                    </div>
                    <div class="form-group">
                        <label for="cat">Product Category </label>
                        <input type="text" id="cat" name="cat" class="form-control" placeholder="product Category">
                    </div>
                    <div class="form-group">
                        <label for="scat">Product sub Category </label>
                        <input type="text" id="scat" name="scat" class="form-control" placeholder="product sub Category">
                    </div>
                    <div class="form-group">
                        <label for="price">Price </label>
                        <input type="text" id="price" name="price" class="form-control" placeholder="price">
                    </div>
                    <div class="form-group">
                        <label for="status">Select </label>
                        <select name="status" id="status" class="form-control">
                            <option value="0">--Select Here--</option>
                            <option value="1">Active</option>
                            <option value="2">Inactive</option>
                        </select>
                    </div>
                    <button class="form-control btn btn-primary mt-3">Save</button>
                    
                </form>
                <a href="{{route('productshows')}}" class="btn btn-info form-control mt-3">Manage Product</a>
            </div>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
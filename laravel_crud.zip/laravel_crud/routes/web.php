<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Backend\productController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[productController::class,'home']);
Route::get('/addproduct',[productController::class,'addproduct'])->name('addproduct');
Route::POST('/showproduct',[productController::class,'showproduct'])->name('showproduct');
Route::get('/productshows',[productController::class,'productshows'])->name('productshows');
Route::get('/editproduct/{id}',[productController::class,'editproduct'])->name('editproduct');
Route::POST('/updateproduct/{id}',[productController::class,'updateproduct'])->name('updateproduct');
Route::get('/deleteproduct/{id}',[productController::class,'deleteproduct'])->name('deleteproduct');
Route::get('/statusupdate/{id}',[productController::class,'statusupdate'])->name('statusupdate');
